# Rubik-s_Race_by_Fifteen_Puzzle

Solves Rubik's Race puzzle by using fifteen puzzle pattern database in one or more 4 by 4 sub-regions.

References:
https://github.com/nellbrodkin/rubiksRace
https://github.com/mschrandt/NPuzzle

About pattern database:
Due to file size limits, the patternDb_4.dat is for the 5-5-5 grouping. You can generate 6-6-3 grouping using the patternDb.py in https://github.com/mschrandt/NPuzzle

To know more about the pattern database:
https://www.youtube.com/watch?v=g0phuZDM6Mg
Felner, A., Korf, R. E., & Hanan, S. (2004). Additive Pattern Database Heuristics. Journal of Artificial Intelligence Research, 22, pp. 279-318 

Run the game:
$ python graphics.py

Reshuffle when "r" is pressed, perform ai moves when "h" is pressed (will build ai solution when "h" is pressed the first time).
